package jk.jspd.cmu.edu.postit.model;

import org.json.JSONObject;
import jk.jspd.cmu.edu.postit.ws.remote.FacebookInterface;
import jk.jspd.cmu.edu.postit.ws.remote.ConnectionInterface;
/**
 * Created by lavalake on 11/13/15.
 */
public class ConnectionManager extends RemoteAbstract implements FacebookInterface, ConnectionInterface {
}
