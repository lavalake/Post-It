package jk.jspd.cmu.edu.postit.Intent;

/**
 * Created by liukaiyu on 11/13/15.
 */
public class PostNewIntent {
}
