package jk.jspd.cmu.edu.postit.ws.remote;

/**
 * Created by lavalake on 11/13/15.
 */
public interface FacebookInterface {
    public void getFriendsList();
    public void getProfile();
}
